#version 120

#define DAMAGE_BLOCK_EFFECT
#define NETHER_SHADER

#include "/dimensions/clrwl_damagedblock.fsh"
